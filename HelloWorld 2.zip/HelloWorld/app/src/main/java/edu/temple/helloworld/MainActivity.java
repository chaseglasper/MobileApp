package edu.temple.helloworld;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button chase;
    TextView hello;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        chase = findViewById(R.id.button);
        chase.setOnClickListener(listener);
        hello = findViewById(R.id.textView);





    }


    public View.OnClickListener listener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {

            hello.setText("You have clicked the button");


        }
    };

}
