package edu.temple.assignment3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Adapter;
import android.widget.TextView;

public class ColorActivity extends AppCompatActivity  {
    ConstraintLayout currentLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        currentLayout = findViewById(R.id.main_layout);


        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        ListView listView = (ListView) findViewById(R.id.listView);

        String[] myStringArray = {"Red", "Green", "Blue", "Indigo"};


        CustomAdapter adapter = new CustomAdapter(ColorActivity.this,
                android.R.layout.simple_spinner_dropdown_item,
                myStringArray);



        adapter.getDropDownView(myStringArray.length, listView, listView);


        spinner.setAdapter(adapter);


        listView.setAdapter(adapter);




        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentLayout.setBackgroundColor(Color.WHITE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                currentLayout.setBackgroundColor(Color.WHITE);

            }


        });
    }
}



